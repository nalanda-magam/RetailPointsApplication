package com.chartercommunication.assesment.RetailPointsApplication.dto;

import lombok.Data;

@Data
public class PointsPerMonth {

    private String month;

    private int points;
}
